JAR is in the following folder, named Nozama.jar

to run (MUST BE RUN FROM COMMAND LINE):
navigate to the directory "JAR Folder"
type 
	java -jar Nozama.jar
and hit enter